package com.example.layeredarchitecture.dao.custom.impl;


import com.example.layeredarchitecture.dao.custom.QueryDAO;

public class QueryDAOImpl implements QueryDAO {
    @Override
    public void searchOrder() {

    }
}
