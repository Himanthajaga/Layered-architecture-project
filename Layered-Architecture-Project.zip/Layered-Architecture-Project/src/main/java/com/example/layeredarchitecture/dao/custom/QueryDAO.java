package com.example.layeredarchitecture.dao.custom;

public interface QueryDAO {
    void searchOrder();
}
